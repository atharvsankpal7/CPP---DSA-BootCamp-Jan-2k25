#include<bits/stdc++.h>
using namespace std;
int main(){
	// input
	int size1;
	int size2;
	cin >> size1 >> size2;
	vector<int> v1(size1);
	vector<int> v2(size2);
	// main logic
	int size3 = size1 + size2;
	vector<int> v3(size3);
	
}
