#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n; 
    //input 
    cin >> n;
    //output
    cout << n << endl;
    cout << "Hello World!" << endl;
 
    return 0;
}